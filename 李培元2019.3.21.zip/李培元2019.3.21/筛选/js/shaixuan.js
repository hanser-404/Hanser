var pArr = [
    {
        name : "Autumn",
        age : 18,
        sex : "男",
        jianjie : "犯得上犯得上发生发射点发射点犯得上"
    },
    {
        name : "小可",
        age : 18,
        sex : "女",
        jianjie : "大美女 哈哈哈哈"
    },
    {
        name : "杰瑞",
        age : 18,
        sex : "人妖",
        jianjie : "萨瓦迪卡 乌西卡玛西狄俄"
    }
];
